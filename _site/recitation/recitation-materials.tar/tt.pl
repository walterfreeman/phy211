print "#x l\n";
for ($i=1;$i<10000;$i++)
{
  $g=(sqrt($i)/2-3)/$i;
  print "$i $g\n";
}
